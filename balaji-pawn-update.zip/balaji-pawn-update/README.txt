BALAJI PAWN BROKERS — App Update Package
==========================================

HOW TO USE
----------
1. Open your PAWN-BROKER repo folder
2. Copy App.tsx and utils.ts into the ROOT of the repo (same level as package.json)
3. Copy all files from the components/ folder into your existing components/ folder
4. Run: npm install && npm run dev  (to test locally)
5. Run: git add . && git commit -m "Bug fixes, camera, filters, autofill" && git push

YOUR DATA IS SAFE
-----------------
Deploying new code never touches localStorage.
All your loan records will be exactly as you left them.

FILES INCLUDED
--------------
Root level (2 files):
  App.tsx        — bug fixes, performance improvements
  utils.ts       — NEW: shared helper functions (place in repo root)

components/ folder (5 files):
  Dashboard.tsx        — overdue indicator, shared utils
  Ledger.tsx           — status filters, overdue badges, WhatsApp reminders
  LoanEntryForm.tsx    — customer autofill dropdown, uses OrnamentCamera
  OrnamentCamera.tsx   — NEW: camera tab + gallery tab with live preview
  SettlementModal.tsx  — fixed stale interest bug, reset button

DO NOT TOUCH (unchanged files — leave as they are):
  types.ts, BackupManager.tsx, StorageSettings.tsx,
  CustomerSheet.tsx, Modal.tsx, ErrorBoundary.tsx, index.tsx

